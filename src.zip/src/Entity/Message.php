<?php

namespace App\Entity;

use App\Repository\MessageRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;
use ApiPlatform\Core\Annotation\ApiResource;

use Symfony\Component\Serializer\Annotation\Groups;

/**
 * @ORM\Entity(repositoryClass=MessageRepository::class)
 * @ApiResource(
 *  itemOperations={
 *          "get"={},
 *          "patch"={
 *              "denormalization_context"={
 *                  "groups"={
 *                     "modify:message"
 *                  }
 *              },
 *             },
 *          "delete"={}
 *     },
 * collectionOperations = { "get" = {
 * "normalization_context"={
 *                  "groups"={
 *                      "read:message"
 *                  }
 *              },
 * 
 * 
 * 
 * 
 * },
 *    "post"={
 *              "denormalization_context"={
 *                  "groups"={
 *                      "create:message"
 *                  }
 *              },
 *            
 *           
 *          }
 * 
 * })
 */
class Message
{
    /**
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(type="integer")
     * @Groups({"read:message"})
     */
    private $id;

    /**
     * @ORM\Column(type="string", length=255)
     * @Groups({"create:message","read:message", "modify:message"})
     */
    private $content;

    /**
     * @ORM\Column(type="datetime")
     * @Groups({"read:message"})
     */
    private $dateCreate;

    /**
     * @ORM\Column(type="boolean")
     * @Groups({"read:message"})
     */
    private $status;

    /**
     * @ORM\ManyToOne(targetEntity=User::class, inversedBy="messages")
     * @Groups({"create:message","read:message"})
     */
    private $emetteur;

    /**
     * @ORM\ManyToOne(targetEntity=user::class, inversedBy="messages")
     * @Groups({"create:message","read:message"})
     */
    private $recepteur;


    /** 
     * @return  
     */

    public function __construct()
    {

        $this->dateCreate = new \DateTime();
        $this->status = 0;
    }



    /** 
     * @return int
     */
    public function getId(): ?int
    {
        return $this->id;
    }
    /** 
     * @return string
     */
    public function getContent(): ?string
    {
        return $this->content;
    }
    /** 
     * @return string
     */
    public function setContent(string $content): self
    {
        $this->content = $content;

        return $this;
    }
    /** 
     * @return DateTimeInterface
     */
    public function getDateCreate(): ?\DateTimeInterface
    {
        return $this->dateCreate;
    }
    /** 
     * @return DateTimeInterface
     */
    public function setDateCreate(\DateTimeInterface $dateCreate): self
    {
        $this->dateCreate = $dateCreate;

        return $this;
    }
    /** 
     * @return bool
     */
    public function getStatus(): ?bool
    {
        return $this->status;
    }
    /** 
     * @return bool
     */
    public function setStatus(bool $status): self
    {
        $this->status = $status;

        return $this;
    }
    /** 
     * @return User
     */
    public function getEmetteur(): ?User
    {
        return $this->emetteur;
    }
    /** 
     * @return User
     */
    public function setEmetteur(?User $emetteur): self
    {
        $this->emetteur = $emetteur;

        return $this;
    }
    /** 
     * @return User
     */
    public function getRecepteur(): ?User
    {
        return $this->recepteur;
    }

    /** 
     * @return User
     */
    public function setRecepteur(?User $recepteur): self
    {
        $this->recepteur = $recepteur;

        return $this;
    }
}
