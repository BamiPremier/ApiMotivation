<?php

namespace App\Entity;

use App\Repository\AbonnementRepository;
use Doctrine\ORM\Mapping as ORM;
use ApiPlatform\Core\Annotation\ApiResource;
use Symfony\Component\Serializer\Annotation\Groups;

/**
 * @ORM\Entity(repositoryClass=AbonnementRepository::class)
 * @ApiResource(collectionOperations = { "get" = {
 * "normalization_context"={
 *                  "groups"={
 *                      "read:abonnemnt"
 *                  }
 *              },
 * 
 * 
 * 
 * 
 * },
 *    "post"={
 *              "denormalization_context"={
 *                  "groups"={
 *                      "create:abonnemnt"
 *                  }
 *              },
 *            
 *           
 *          }
 * 
 * })
 */
class Abonnement
{
    /**
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(type="integer")
     * @Groups({"read:abonnemnt"})
     */
    private $id;

    /**
     * @ORM\Column(type="datetime")
     * @Groups({"read:abonnemnt"})
     */
    private $dateAbonnement;

    /**
     * @ORM\ManyToOne(targetEntity=User::class, inversedBy="abonnements")
     * @Groups({"create:abonnemnt","read:abonnemnt"})
     */
    private $user;
    /** 
     * @return  
     */
    public function __construct()
    {

        $this->dateAbonnement = new \DateTime();
    }
    /** 
     * @return int
     */
    public function getId(): ?int
    {
        return $this->id;
    }
    /** 
     * @return DateTimeInterface
     */
    public function getDateAbonnement(): ?\DateTimeInterface
    {
        return $this->dateAbonnement;
    }
    /** 
     * @return DateTimeInterface
     */
    public function setDateAbonnement(\DateTimeInterface $dateAbonnement): self
    {
        $this->dateAbonnement = $dateAbonnement;

        return $this;
    }
    /** 
     * @return User
     */
    public function getUser(): ?User
    {
        return $this->user;
    }
    /** 
     * @return User
     */
    public function setUser(?User $user): self
    {
        $this->user = $user;

        return $this;
    }
}
