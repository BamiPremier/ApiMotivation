<?php

namespace App\Entity;

use App\Repository\LikeRepository;
use Doctrine\ORM\Mapping as ORM;
use ApiPlatform\Core\Annotation\ApiResource;

use Symfony\Component\Serializer\Annotation\Groups;

/**
 * @ORM\Entity(repositoryClass=LikeRepository::class)
 * @ORM\Table(name="`like`")
 * @ApiResource( itemOperations={
 *          "get"={},
 *         
 *          "delete"={}
 *     },
 * collectionOperations = { "get" = {
 * "normalization_context"={
 *                  "groups"={
 *                      "read:like"
 *                  }
 *              },
 * 
 * 
 * 
 * 
 * },
 *    "post"={
 *              "denormalization_context"={
 *                  "groups"={
 *                      "create:like"
 *                  }
 *              },
 *            
 *           
 *          }
 * 
 * })
 */
class Like
{
    /**
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(type="integer")
     * @Groups({"read:like"})
     */
    private $id;

    /**
     * @ORM\Column(type="datetime") 
     * @Groups({"read:like"})
     */
    private $dateLike;

    /**
     * @ORM\ManyToOne(targetEntity=Publication::class, inversedBy="likes") 
     * @Groups({"create:like","read:like"})
     */
    private $publication;

    /**
     * @ORM\ManyToOne(targetEntity=User::class, inversedBy="likes")
     * 
     * @Groups({"create:like","read:like"})
     */
    private $user;
    /** 
     * @return  
     */
    public function __construct()
    {

        $this->dateLike = new \DateTime();
    }
    /** 
     * @return int
     */
    public function getId(): ?int
    {
        return $this->id;
    }
    /** 
     * @return DateTimeInterface
     */
    public function getDateLike(): ?\DateTimeInterface
    {
        return $this->dateLike;
    }
    /** 
     * @return DateTimeInterface
     */
    public function setDateLike(\DateTimeInterface $dateLike): self
    {
        $this->dateLike = $dateLike;

        return $this;
    }
    /** 
     * @return Publication
     */
    public function getPublication(): ?Publication
    {
        return $this->publication;
    }
    /** 
     * @return Publication
     */
    public function setPublication(?Publication $publication): self
    {
        $this->publication = $publication;

        return $this;
    }
    /** 
     * @return User
     */
    public function getUser(): ?User
    {
        return $this->user;
    }
    /** 
     * @return User
     */
    public function setUser(?User $user): self
    {
        $this->user = $user;

        return $this;
    }
}
